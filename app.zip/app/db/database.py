from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.core.config import settings
import ssl

# For Neon/PostgreSQL with SSL
Base = declarative_base()

engine = create_engine(
    settings.DATABASE_URL,
    echo=True,  # Set to False in production
    pool_size=5,
    max_overflow=10,
    pool_pre_ping=True,
    pool_recycle=300,
    # For Neon SSL
    connect_args={
        "ssl": ssl.create_default_context(cafile="")
    } if "neon.tech" in settings.DATABASE_URL else {}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)