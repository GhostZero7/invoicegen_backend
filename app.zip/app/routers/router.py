from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.database import SessionLocal
from app.db.models.user import User

api_router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@api_router.get("/test-db")
def test_db_connection(db: Session = Depends(get_db)):
    try:
        # Try to query users table
        users_count = db.query(User).count()
        return {
            "status": "connected",
            "users_count": users_count,
            "message": "Database connection successful"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")